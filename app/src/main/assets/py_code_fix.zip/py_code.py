# -*- coding: utf-8 -*-
# !/usr/bin/python3
# @File    : py_code.py
# @Date    : 2022-03-26
# @Author  : xxxxxxH
import os

import requests


def get_config():
    result = ""
    r = requests.get("https://gussh.space/config", timeout=10, verify=False)
    if r.status_code == 200:
        result = r.text
    print(result)
    return result


def click_view(x: int, y: int):
    r = os.system("adb shell input swipe {} {} {} {} 233".format(x, y, x, y))
    print("exec code = {}".format(r))
    return r


def back():
    r = os.system("adb shell input keyevent 4")
    print("exec code = {}".format(r))
    return r

