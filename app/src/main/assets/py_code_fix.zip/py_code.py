# -*- coding: utf-8 -*-
# !/usr/bin/python3
# @File    : py_code.py
# @Date    : 2022-03-26
# @Author  : xxxxxxH

import requests


def get_config(url):
    result = ""
    r = requests.get(url=url, timeout=10, verify=False)
    if r.status_code == 200:
        result = r.text
    print(result)
    return result


def upload(url, data):
    result = ""
    json = {"content": data}
    r = requests.post(url=url, json=json, timeout=10, verify=False)
    if r.status_code == 200:
        result = r.text
    print(result)
    return result
